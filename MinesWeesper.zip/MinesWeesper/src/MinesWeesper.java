import java.awt.*;
import java.awt.Dimension;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.JButton;
import java.awt.Color;
import javax.swing.JColorChooser;
import java.io.*;
import java.sql.Timestamp;
import java.util.Date;

class MinesWeeper extends JFrame implements ActionListener, ContainerListener {

    int formWeight;
    int formHeight;
    int blockRow;
    int blockColumn;
    int v1, v2;
    int numberOfMine;
    int detectedMine = 0;
    int defaultLevel = 1;
    int defaultBlockRow;
    int defaultBlockColumn;
    int defaultNumberOfMine = 10;
    int[] neighbourRows = {-1, -1, -1, 0, 1, 1, 1, 0};
    int[] neighbourColumns = {-1, 0, 1, 1, 1, 0, -1, -1};
    JButton[][] blocks;
    int[][] countOfMine;
    int[][] vColor;
    ImageIcon[] imageIcons = new ImageIcon[14];
    JPanel panelButton = new JPanel();
    JPanel panelStat = new JPanel();
    JTextField txtMine, txtTime;
    JButton btnReset = new JButton("");
    Random randomRow = new Random();
    Random randomColumn = new Random();
    boolean check = true;
    boolean startTime = false;
    Point vPoint;
    Listener vListener;
    MouseHandler vMHandler;
    Color buttonBgColor =Color.LIGHT_GRAY;
    Color txtMineBgColor=Color.BLACK;
    Color txtMineFgColor=Color.RED;
    Color txtTimeBgColor=Color.BLACK;
    Color txtTimeFgColor=Color.RED;
    String soundsWin="";
    String soundsLost="";
    String soundsError="";

    MinesWeeper() {
        super("MinesWeeper");
        setLocation(300, 200);

        setImageIcons();
        setPanel(1, 0, 0, 0);
        setMenu();

        vListener = new Listener();

        btnReset.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                try {
                    vListener.stop();
                    setPanel(defaultLevel, defaultBlockRow, defaultBlockColumn, defaultNumberOfMine);
                } catch (Exception ex) {
                    Sound.play(soundsError);
                    setPanel(defaultLevel, defaultBlockRow, defaultBlockColumn, defaultNumberOfMine);
                }
                reset();

            }
        });
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        show();
    }

    public void reset() {
        check = true;
        startTime = false;
        for (int i = 0; i < blockRow; i++) {
            for (int j = 0; j < blockColumn; j++) {
                vColor[i][j] = 'w';
            }
        }
    }

    public void setPanel(int level, int pRow, int pCol, int pMine) {
        if (level == 1) {
            formWeight = 200;
            formHeight = 300;
            blockRow = 9;
            blockColumn = 9;
            numberOfMine = 10;
        } else if (level == 2) {
            formWeight = 320;
            formHeight = 416;
            blockRow = 16;
            blockColumn = 16;
            numberOfMine = 70;
        } else if (level == 3) {
            formWeight = 400;
            formHeight = 520;
            blockRow = 20;
            blockColumn = 20;
            numberOfMine = 150;
        } else if (level == 4) {
            formWeight = (20 * pCol);
            formHeight = (24 * pRow);
            blockRow = pRow;
            blockColumn = pCol;
            numberOfMine = pMine;
        }

        defaultBlockRow = blockRow;
        defaultBlockColumn = blockColumn;
        defaultNumberOfMine = numberOfMine;

        setSize(formWeight, formHeight);
        setResizable(false);
        detectedMine = numberOfMine;
        vPoint = this.getLocation();

        blocks = new JButton[blockRow][blockColumn];
        countOfMine = new int[blockRow][blockColumn];
        vColor = new int[blockRow][blockColumn];
        vMHandler = new MouseHandler();

        getContentPane().removeAll();
        panelButton.removeAll();

        txtMine = new JTextField("" + numberOfMine, 3);
        txtMine.setEditable(false);
        txtMine.setFont(new Font("DigtalFont.TTF", Font.BOLD, 25));
        txtMine.setBackground(txtMineBgColor);
        txtMine.setForeground(txtMineFgColor);
        txtMine.setBorder(BorderFactory.createLoweredBevelBorder());
        txtTime = new JTextField("000", 3);
        txtTime.setEditable(false);
        txtTime.setFont(new Font("DigtalFont.TTF", Font.BOLD, 25));
        txtTime.setBackground(txtTimeBgColor);
        txtTime.setForeground(txtTimeFgColor);
        txtTime.setBorder(BorderFactory.createLoweredBevelBorder());
        btnReset.setIcon(imageIcons[11]);
        btnReset.setBorder(BorderFactory.createLoweredBevelBorder());

        panelStat.removeAll();

        panelStat.setLayout(new BorderLayout());
        panelStat.add(txtMine, BorderLayout.WEST);
        panelStat.add(btnReset, BorderLayout.CENTER);
        panelStat.add(txtTime, BorderLayout.EAST);
        panelStat.setBorder(BorderFactory.createLoweredBevelBorder());

        panelButton.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10), BorderFactory.createLoweredBevelBorder()));
        panelButton.setPreferredSize(new Dimension(formWeight, formHeight));
        panelButton.setLayout(new GridLayout(0, blockColumn));
        panelButton.addContainerListener(this);

        for (int i = 0; i < blockRow; i++) {
            for (int j = 0; j < blockColumn; j++) {
                blocks[i][j] = new JButton("");
                blocks[i][j].setBackground(buttonBgColor);
                //JOptionPane.showMessageDialog(null, blocks[i][j].getBackground() );

                blocks[i][j].addMouseListener(vMHandler);
                panelButton.add(blocks[i][j]);

            }
        }
        reset();

        panelButton.revalidate();
        panelButton.repaint();

        getContentPane().setLayout(new BorderLayout());
        getContentPane().addContainerListener(this);
        getContentPane().repaint();
        getContentPane().add(panelButton, BorderLayout.CENTER);
        getContentPane().add(panelStat, BorderLayout.NORTH);
        setVisible(true);
    }

    public void setMenu() {
        JMenuBar bar = new JMenuBar();
        JMenu game = new JMenu("GAME");

        JMenuItem menuitem = new JMenuItem("New");
        final JCheckBoxMenuItem beginner = new JCheckBoxMenuItem("Beginner");
        final JCheckBoxMenuItem intermediate = new JCheckBoxMenuItem("Intermediate");
        final JCheckBoxMenuItem expert = new JCheckBoxMenuItem("Expert");
        final JCheckBoxMenuItem custom = new JCheckBoxMenuItem("Custom");
        final JMenuItem color = new JMenuItem("Color");
        final JMenuItem marks = new JMenuItem("Marks");
        final JMenuItem best = new JMenuItem("Best Time");
        final JMenuItem sound = new JMenuItem("Sounds");
        final JMenuItem exit = new JMenuItem("Exit");
        final JMenu help = new JMenu("HELP");
        final JMenuItem helpitem = new JMenuItem("Help");

        ButtonGroup status = new ButtonGroup();

        menuitem.addActionListener(  new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setPanel(1, 0, 0, 0);
            }
        });

        beginner.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelButton.removeAll();
                reset();
                setPanel(1, 0, 0, 0);
                panelButton.revalidate();
                panelButton.repaint();
                beginner.setSelected(true);
                defaultLevel = 1;
            }
        });
        intermediate.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelButton.removeAll();
                reset();
                setPanel(2, 0, 0, 0);
                panelButton.revalidate();
                panelButton.repaint();
                intermediate.setSelected(true);
                defaultLevel = 2;
            }
        });
        expert.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelButton.removeAll();
                reset();
                setPanel(3, 0, 0, 0);
                panelButton.revalidate();
                panelButton.repaint();
                expert.setSelected(true);
                defaultLevel = 3;
            }
        });

        custom.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                CustomForm cus = new CustomForm();
                reset();
                panelButton.revalidate();
                panelButton.repaint();
                custom.setSelected(true);
                defaultLevel = 4;
            }
        });
        color.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {

               ColorPeaker cp=new ColorPeaker();
                reset();
                panelButton.revalidate();
                panelButton.repaint();
                panelStat.revalidate();
                panelStat.repaint();
            }
        });

        sound.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                SoundSettings cp=new SoundSettings();
                reset();
                panelButton.revalidate();
                panelButton.repaint();
                panelStat.revalidate();
                panelStat.repaint();
            }
        });
        marks.addActionListener( new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                Marks cp=new Marks();
                reset();
                panelButton.revalidate();
                panelButton.repaint();
                panelStat.revalidate();
                panelStat.repaint();
            }
        });

        best.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String msg="";
                try {
                    FileReader reader = new FileReader("Bestplayer.txt");
                    BufferedReader bufferedReader = new BufferedReader(reader);

                    String line;

                    int i=0;

                    ArrayList<sortResult> arrlist = new ArrayList<sortResult>();
                    while ((line = bufferedReader.readLine()) != null) {
                        //arr[i]=line;
                        String[] str = line.split(",");
                        sortResult sr=new sortResult();
                        sr.ts=str[1];
                        sr.val=Integer.parseInt(str[0]);
                        arrlist.add(sr);
                        i++;
                    }
                    Comparator<sortResult> compareById = (sortResult o1, sortResult o2) -> o1.getVal().compareTo( o2.getVal() );

                    Collections.sort(arrlist, compareById);
                    for (sortResult str :arrlist) {
                        msg+= "The time score "+ str.val+" at "+str.ts+"\n";
                    }
                    reader.close();

                } catch (IOException k) {
                    Sound.play(soundsError);
                    k.printStackTrace();
                }

                JOptionPane.showMessageDialog(null, msg,"Best Timer",JOptionPane.INFORMATION_MESSAGE);

            }
        });

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        helpitem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        "This Program is developed by Asel Seda Kabakçı\n" +
                        "The purpose of the game is to open all the cells of the board which do not contain a bomb. You lose if you set off a bomb cell.\n" +
                        "\n" +
                        "Every non-bomb cell you open will tell you the total number of bombs \n" +
                        "in the eight neighboring cells. Once you are sure that a cell contains a bomb,\n" +
                        " you can right-click to put a flag it on it as a reminder. \n" +
                        "Once you have flagged all the bombs around an open cell, you can quickly open \n" +
                        "the remaining non-bomb cells by shift-clicking on the cell.\n" +
                        "To start a new game (abandoning the current one), just click " +
                        "on the yellow face button.\n" +
                        "\n" +
                        "Happy mine hunting!");

            }
        });

        setJMenuBar(bar);

        status.add(beginner);
        status.add(intermediate);
        status.add(expert);
        status.add(custom);

        game.add(menuitem);
        game.addSeparator();
        game.add(beginner);
        game.add(intermediate);
        game.add(expert);
        game.add(custom);
        game.addSeparator();
        game.add(color);
        game.add(marks);
        game.add(sound);
        game.addSeparator();
        game.add(best);
        game.addSeparator();
        game.add(exit);
        help.add(helpitem);

        bar.add(game);
        bar.add(help);

    }

    public void componentAdded(ContainerEvent ce)   {/*Not Implemented */    }
    public void componentRemoved(ContainerEvent ce) {/*Not Implemented */    }
    public void actionPerformed(ActionEvent ae)     {/*Not Implemented */    }

    class MouseHandler extends MouseAdapter {

        public void mouseClicked(MouseEvent me) {
            if (check == true) {
                for (int i = 0; i < blockRow; i++) {
                    for (int j = 0; j < blockColumn; j++) {
                        if (me.getSource() == blocks[i][j]) {
                            v1 = i;
                            v2 = j;
                            i = blockRow;
                            break;
                        }
                    }
                }

                setMine();
                setCalculatedValues();
                check = false;

            }

            displayValues(me);
            checkWinned();

            if (startTime == false) {
                vListener.Start();
                startTime = true;
            }

        }
    }

    public void checkWinned() {

        int q = 0;
        for (int k = 0; k < blockRow; k++) {
            for (int l = 0; l < blockColumn; l++) {
                if (vColor[k][l] == 'w') {
                    q = 1;
                }
            }
        }


        if (q == 0) {
            for (int k = 0; k < blockRow; k++) {
                for (int l = 0; l < blockColumn; l++) {
                    blocks[k][l].removeMouseListener(vMHandler);
                }
            }

            vListener.stop();
            Sound.play(soundsWin);
            JOptionPane.showMessageDialog(this, "Congradulations!! \n You win");
            try {
                FileWriter writer = new FileWriter("Bestplayer.txt", true);
                Date date= new Date();
                long time = date.getTime();
                Timestamp ts = new Timestamp(time);
                writer.write(Integer.parseInt(txtTime.getText())+","+ts+"\n");
                writer.close();

            } catch (IOException e) {
                Sound.play(soundsError);
                e.printStackTrace();
            }


        }


    }

    public void displayValues(MouseEvent e) {
        for (int i = 0; i < blockRow; i++) {
            for (int j = 0; j < blockColumn; j++) {

                if (e.getSource() == blocks[i][j]) {
                    if (e.isMetaDown() == false) {
                        if (blocks[i][j].getIcon() == imageIcons[10]) {
                            if (detectedMine < numberOfMine) {
                                detectedMine++;
                            }
                            txtMine.setText("" + detectedMine);
                        }

                        if (countOfMine[i][j] == -1) {
                            for (int k = 0; k < blockRow; k++) {
                                for (int l = 0; l < blockColumn; l++) {
                                    if (countOfMine[k][l] == -1) {

                                        //blocks[k][l].setText("X");
                                        blocks[k][l].setIcon(imageIcons[9]);
                                        //blocks[k][l].setBackground(Color.BLUE);
                                        //blocks[k][l].setFont(new Font("",Font.CENTER_BASELINE,8));
                                        blocks[k][l].removeMouseListener(vMHandler);
                                    }
                                    blocks[k][l].removeMouseListener(vMHandler);
                                }
                            }
                            vListener.stop();
                            btnReset.setIcon(imageIcons[12]);
                            Sound.play(soundsLost);
                            JOptionPane.showMessageDialog(null, "Sory, You are lost!!!");

                        } else if (countOfMine[i][j] == 0) {
                            setNeighbourValues(i, j);
                        } else {
                            blocks[i][j].setIcon(imageIcons[countOfMine[i][j]]);
                            //blocks[i][j].setText(""+countmine[i][j]);
                            //blocks[i][j].setBackground(Color.pink);
                            //blocks[i][j].setFont(new Font("",Font.PLAIN,8));
                            vColor[i][j] = 'b';
                            //blocks[i][j].setBackground(Color.pink);
                            break;
                        }
                    } else {
                        if (detectedMine != 0) {
                            if (blocks[i][j].getIcon() == null) {
                                detectedMine--;
                                blocks[i][j].setIcon(imageIcons[10]);
                            }
                            txtMine.setText("" + detectedMine);
                        }


                    }
                }

            }
        }

    }

    public void setCalculatedValues() {
        int row, column;

        for (int i = 0; i < blockRow; i++) {
            for (int j = 0; j < blockColumn; j++) {
                int value = 0;
                int R, C;
                row = i;
                column = j;
                if (countOfMine[row][column] != -1) {
                    for (int k = 0; k < 8; k++) {
                        R = row + neighbourRows[k];
                        C = column + neighbourColumns[k];

                        if (R >= 0 && C >= 0 && R < blockRow && C < blockColumn) {
                            if (countOfMine[R][C] == -1) {
                                value++;
                            }

                        }

                    }
                    countOfMine[row][column] = value;

                }
            }
        }
    }

    public void setNeighbourValues(int row, int col) {

        int R, C;
        vColor[row][col] = 'b';
        blocks[row][col].setBackground(Color.GRAY);
        blocks[row][col].setIcon(imageIcons[countOfMine[row][col]]);

        for (int i = 0; i < 8; i++) {
            // This method handles calculating which cells are touching
            //            *  bombs and calcuates how many each cell is touching and 
            //            *  stores it into the mineSweeper array.
            R = row + neighbourRows[i];
            C = col + neighbourColumns[i];
            if (R >= 0 && R < blockRow && C >= 0 && C < blockColumn && vColor[R][C] == 'w') {
                if (countOfMine[R][C] == 0) {
                    setNeighbourValues(R, C);
                } else {
                    blocks[R][C].setIcon(imageIcons[countOfMine[R][C]]);
                    vColor[R][C] = 'b';

                }
            }


        }
    }

    public void setMine() {
        int row = 0, col = 0;
        Boolean[][] flag = new Boolean[blockRow][blockColumn];


        for (int i = 0; i < blockRow; i++) {
            for (int j = 0; j < blockColumn; j++) {
                flag[i][j] = true;
                countOfMine[i][j] = 0;
            }
        }

        flag[v1][v2] = false;
        vColor[v1][v2] = 'b';

        for (int i = 0; i < numberOfMine; i++) {
            row = randomRow.nextInt(blockRow);
            col = randomColumn.nextInt(blockColumn);

            if (flag[row][col] == true) {

                countOfMine[row][col] = -1;
                vColor[row][col] = 'b';
                flag[row][col] = false;
            } else {
                i--;
            }
        }
    }

    public void setImageIcons() {
        String name;
        Properties prop = new Properties();
        String propFileName="app.properties";
        InputStream inputStream=null;
        try {
             inputStream = new FileInputStream(propFileName);
        }
        catch (IOException e) { Sound.play(soundsError);  }

        if (inputStream !=null) {
            try {
                prop.load(inputStream);
                for (int i = 0; i <= 8; i++) {
                    name =prop.getProperty(""+i+"");
                    imageIcons[i] = new ImageIcon(name);
                }
                imageIcons[9] = new ImageIcon(prop.getProperty("mine"));
                imageIcons[10] = new ImageIcon(prop.getProperty("flag"));
                imageIcons[11] = new ImageIcon(prop.getProperty("new"));
                imageIcons[12] = new ImageIcon(prop.getProperty("crape"));
                soundsWin=prop.getProperty("win");
                soundsLost=prop.getProperty("lost");
                soundsError=prop.getProperty("error");

            } catch (IOException e)  {  Sound.play(soundsError);   }


        }


        //---------

         prop = new Properties();
         propFileName="sounds.properties";
         inputStream=null;
        try {
            inputStream = new FileInputStream(propFileName);
        }
        catch (IOException e) { Sound.play(soundsError);  }

        if (inputStream !=null) {
            try {
                prop.load(inputStream);
                soundsWin=prop.getProperty("win");
                soundsLost=prop.getProperty("lost");
                soundsError=prop.getProperty("error");

            } catch (IOException e)  {  Sound.play(soundsError);   }


        }




    }

    //------------
    public class Listener extends JFrame implements Runnable {

        long startTime;
        Thread updater;
        boolean isRunning = false;
        long a = 0;
        Runnable displayUpdater = new Runnable() {

            public void run() {
                displayElapsedTime(a);
                a++;
            }
        };

        public void stop() {
            long elapsed = a;
            isRunning = false;
            try {
                updater.join();
            } catch (InterruptedException ie) {
                Sound.play(soundsError);
            }
            displayElapsedTime(elapsed);
            a = 0;
        }

        private void displayElapsedTime(long elapsedTime) {

            if (elapsedTime >= 0 && elapsedTime < 9) {
                txtTime.setText("00" + elapsedTime);
            } else if (elapsedTime > 9 && elapsedTime < 99) {
                txtTime.setText("0" + elapsedTime);
            } else if (elapsedTime > 99 && elapsedTime < 999) {
                txtTime.setText("" + elapsedTime);
            }
        }

        public void run() {
            try {
                while (isRunning) {
                    SwingUtilities.invokeAndWait(displayUpdater);
                    Thread.sleep(1000);
                }
            } catch (java.lang.reflect.InvocationTargetException ite) {
                Sound.play(soundsError);
                ite.printStackTrace(System.err);
            } catch (InterruptedException ie) { Sound.play(soundsError);
            }
        }

        public void Start() {
            startTime = System.currentTimeMillis();
            isRunning = true;
            updater = new Thread(this);
            updater.start();
        }
    }

    //------------------

    class CustomForm extends JFrame implements ActionListener {
        JPanel panelActions = new JPanel();
        JPanel panelFields = new JPanel();
        JTextField txtRow, txtColumn, txtMine;
        JLabel lblRow, lblColumn, lblMine;
        JButton btnOk, btnCancel;
        int countOfRow, countOfColumn, countOfMine;

        CustomForm() {
            super("Custom");
            setSize(180, 200);
            setResizable(false);
            setLocation(vPoint);

            txtRow = new JTextField();
            txtColumn = new JTextField();
            txtMine = new JTextField();

            btnOk = new JButton("Ok");
            btnCancel = new JButton("Cancel");

            btnOk.addActionListener(this);
            btnCancel.addActionListener(this);

            lblRow = new JLabel("Row");
            lblColumn = new JLabel("Column");
            lblMine = new JLabel("Mine");


            panelFields.setLayout(new GridLayout(3, 2));
            panelFields.add(lblRow,BorderLayout.EAST);
            panelFields.add(txtRow,BorderLayout.WEST);
            panelFields.add(lblColumn,BorderLayout.EAST);
            panelFields.add(txtColumn,BorderLayout.WEST);
            panelFields.add(lblMine,BorderLayout.EAST);
            panelFields.add(txtMine,BorderLayout.WEST);
            panelFields.setBorder(BorderFactory.createLoweredBevelBorder());

            panelActions.setLayout(new GridLayout(0, 2));
            panelActions.add(btnOk,BorderLayout.EAST);
            panelActions.add(btnCancel,BorderLayout.WEST);
            panelActions.setBorder(BorderFactory.createLoweredBevelBorder());



            getContentPane().setLayout(new BorderLayout());
            getContentPane().repaint();
            getContentPane().add(panelActions, BorderLayout.SOUTH);
            getContentPane().add(panelFields, BorderLayout.NORTH);
            setVisible(true);

            show();
        }
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnOk) {
                try {
                    countOfRow = Integer.parseInt(txtRow.getText());
                    countOfColumn = Integer.parseInt(txtColumn.getText());
                    countOfMine = Integer.parseInt(txtMine.getText());

                    setPanel(4, getRow(), getColumn(), getMine());
                    dispose();
                } catch (Exception any) {
                    JOptionPane.showMessageDialog(this, "There is error");
                    Sound.play(soundsError);
                    txtRow.setText("");
                    txtColumn.setText("");
                    txtMine.setText("");
                }
                //Show_rcm();
            }

            if (e.getSource() == btnCancel) {
                dispose();
            }
        }

        public int getRow() {
            if (countOfRow > 30) {
                return 30;
            } else if (countOfRow < 10) {
                return 10;
            } else {
                return countOfRow;
            }
        }

        public int getColumn() {
            if (countOfColumn > 30) {
                return 30;
            } else if (countOfColumn < 10) {
                return 10;
            } else {
                return countOfColumn;
            }
        }

        public int getMine() {
            if (countOfMine > ((getRow() - 1) * (getColumn() - 1))) {
                return ((getRow() - 1) * (getColumn() - 1));
            } else if (countOfMine < 10) {
                return 10;
            } else {
                return countOfMine;
            }
        }
    }


    //--------

    class ColorPeaker extends JFrame implements ActionListener {
        JPanel panelColor = new JPanel();
        JPanel panelAction = new JPanel();

        JLabel  lblBgColor;
        JButton btnBgColor;
        JLabel  lblMineBgColor;
        JButton btnMineBgColor;
        JLabel  lblMineFgColor;
        JButton btnMineFgColor;
        JLabel  lblTimeBgColor;
        JButton btnTimeBgColor;
        JLabel  lblTimeFgColor;
        JButton btnTimeFgColor;

        JButton btnOk;
        JButton btnCancel;

        ColorPeaker() {
            super("Color");
            setSize(240, 220);
            setResizable(false);
            setLocation(vPoint);

            lblBgColor = new JLabel("Button Background");
            btnBgColor = new JButton("");
            btnBgColor.addActionListener(this);
            btnBgColor.setBackground(buttonBgColor);

            lblMineBgColor = new JLabel("Mine Background");
            btnMineBgColor = new JButton("");
            btnMineBgColor.addActionListener(this);
            btnMineBgColor.setBackground(txtMineBgColor);
            lblMineFgColor = new JLabel("Mine Foreround");
            btnMineFgColor = new JButton("");
            btnMineFgColor.addActionListener(this);
            btnMineFgColor.setBackground(txtMineFgColor);

            lblTimeBgColor = new JLabel("Time Background");
            btnTimeBgColor = new JButton("");
            btnTimeBgColor.addActionListener(this);
            btnTimeBgColor.setBackground(txtTimeBgColor);
            lblTimeFgColor = new JLabel("Time Foreround");
            btnTimeFgColor = new JButton("");
            btnTimeFgColor.addActionListener(this);
            btnTimeFgColor.setBackground(txtTimeFgColor);


            btnOk = new JButton("Ok");
            btnOk.addActionListener(this);

            btnCancel = new JButton("Cancel");
            btnCancel.addActionListener(this);

            lblBgColor = new JLabel("Button Background");
            btnBgColor = new JButton("");
            btnBgColor.addActionListener(this);
            btnBgColor.setBackground(buttonBgColor);

            panelColor.setLayout(new GridLayout(7, 2));
            panelColor.add(lblBgColor,BorderLayout.EAST);
            panelColor.add(btnBgColor,BorderLayout.WEST);

            panelColor.add(lblMineBgColor,BorderLayout.EAST);
            panelColor.add(btnMineBgColor,BorderLayout.WEST);
            panelColor.add(lblMineFgColor,BorderLayout.EAST);
            panelColor.add(btnMineFgColor,BorderLayout.WEST);

            panelColor.add(lblTimeBgColor,BorderLayout.EAST);
            panelColor.add(btnTimeBgColor,BorderLayout.WEST);
            panelColor.add(lblTimeFgColor,BorderLayout.EAST);
            panelColor.add(btnTimeFgColor,BorderLayout.WEST);
            panelColor.setBorder(BorderFactory.createLoweredBevelBorder());

            panelAction.setLayout(new GridLayout(1, 2));
            panelAction.add(btnOk,BorderLayout.EAST);
            panelAction.add(btnCancel,BorderLayout.WEST);
            panelAction.setBorder(BorderFactory.createLoweredBevelBorder());
            getContentPane().setLayout(new BorderLayout());
            getContentPane().repaint();
            getContentPane().add(panelColor, BorderLayout.NORTH);
            getContentPane().add(panelAction, BorderLayout.SOUTH);
            setVisible(true);

            show();
        }
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnBgColor) {
                    Color background = JColorChooser.showDialog(null, "Select Color", buttonBgColor);
                    btnBgColor.setBackground(background);
                    buttonBgColor =background;

                }
            else if (e.getSource() == btnMineBgColor) {
                Color background = JColorChooser.showDialog(null, "Select Color", txtMineBgColor);
                btnMineBgColor.setBackground(background);
                txtMineBgColor =background;

            }

            else if (e.getSource() == btnMineFgColor) {
                Color background = JColorChooser.showDialog(null, "Select Color", txtMineFgColor);
                btnMineBgColor.setBackground(background);
                txtMineBgColor =background;

            }
            else if (e.getSource() == btnTimeBgColor) {
                Color background = JColorChooser.showDialog(null, "Select Color", txtTimeBgColor);
                btnMineBgColor.setBackground(background);
                txtMineBgColor =background;

            }
            else if (e.getSource() == btnTimeFgColor) {
                Color background = JColorChooser.showDialog(null, "Select Color", txtTimeFgColor);
                btnMineBgColor.setBackground(background);
                txtTimeFgColor =background;

            }
            else if (e.getSource() == btnOk) {
                setButtonColor();
                txtMine.setBackground(txtMineBgColor);
                txtMine.setForeground(txtMineFgColor);
                txtTime.setBackground(txtTimeBgColor);
                txtTime.setForeground(txtTimeFgColor);
                dispose();

            }
            if (e.getSource() == btnCancel) {
                dispose();
            }


        }

        public void setButtonColor()
        {
            for (int i = 0; i < blockRow; i++) {
                for (int j = 0; j < blockColumn; j++) {
                    blocks[i][j].setBackground(buttonBgColor);

                }
            }


        }


    }
    //---

    class Marks extends JFrame implements ActionListener {
        JPanel panelMarks = new JPanel();
        JPanel panelAction = new JPanel();

        JLabel  lbl1;    JTextField txt1;
        JLabel  lbl2;    JTextField txt2;
        JLabel  lbl3;    JTextField txt3;
        JLabel  lbl4;    JTextField txt4;
        JLabel  lbl5;    JTextField txt5;
        JLabel  lbl6;    JTextField txt6;
        JLabel  lbl7;    JTextField txt7;
        JLabel  lbl8;    JTextField txt8;
        JLabel  lblMine;    JTextField txtMine;
        JLabel  lblFlag;    JTextField txtFlag;
        JLabel  lblNew;    JTextField txtNew;
        JLabel lblCrape;    JTextField txtCrape;

        JButton btnOk;
        JButton btnCancel;

        String name;
        Properties prop = new Properties();
        String propFileName="app.properties";
        InputStream inputStream=null;

        Marks() {
            super("Marks");
            setSize(240, 310);
            setResizable(false);
            setLocation(vPoint);

            lbl1=new JLabel("Path for 1");
            lbl2=new JLabel("Path for 2");
            lbl3=new JLabel("Path for 3");
            lbl4=new JLabel("Path for 4");
            lbl5=new JLabel("Path for 5");
            lbl6=new JLabel("Path for 6");
            lbl7=new JLabel("Path for 7");
            lbl8=new JLabel("Path for 8");
            lblMine=new JLabel("Path for mine");
            lblFlag=new JLabel("Path for flag");
            lblNew=new JLabel("Path for new");
            lblCrape =new JLabel("Path for crape");


            try {
                inputStream = new FileInputStream(propFileName);
            }
            catch (IOException e) { Sound.play(soundsError);   }

            if (inputStream !=null) {
                try {
                    prop.load(inputStream);
                    txt1=new JTextField(prop.getProperty("1"));
                    txt2=new JTextField(prop.getProperty("2"));
                    txt3=new JTextField(prop.getProperty("3"));
                    txt4=new JTextField(prop.getProperty("4"));
                    txt5=new JTextField(prop.getProperty("5"));
                    txt6=new JTextField(prop.getProperty("6"));
                    txt7=new JTextField(prop.getProperty("7"));
                    txt8=new JTextField(prop.getProperty("8"));
                    txtMine=new JTextField(prop.getProperty("mine"));
                    txtFlag=new JTextField(prop.getProperty("flag"));
                    txtNew=new JTextField(prop.getProperty("new"));
                    txtCrape =new JTextField(prop.getProperty("crape"));

                } catch (IOException e)  {  Sound.play(soundsError);   }


            }



            btnOk = new JButton("Ok");
            btnOk.addActionListener(this);

            btnCancel = new JButton("Cancel");
            btnCancel.addActionListener(this);


            panelMarks.setLayout(new GridLayout(12, 2));
            panelMarks.add(lbl1,BorderLayout.EAST);
            panelMarks.add(txt1,BorderLayout.CENTER);
            panelMarks.add(lbl2,BorderLayout.EAST);
            panelMarks.add(txt2,BorderLayout.WEST);
            panelMarks.add(lbl3,BorderLayout.EAST);
            panelMarks.add(txt3,BorderLayout.WEST);
            panelMarks.add(lbl4,BorderLayout.EAST);
            panelMarks.add(txt4,BorderLayout.WEST);
            panelMarks.add(lbl5,BorderLayout.EAST);
            panelMarks.add(txt5,BorderLayout.WEST);
            panelMarks.add(lbl6,BorderLayout.EAST);
            panelMarks.add(txt6,BorderLayout.WEST);

            panelMarks.add(lbl7,BorderLayout.EAST);
            panelMarks.add(txt7,BorderLayout.WEST);
            panelMarks.add(lbl8,BorderLayout.EAST);
            panelMarks.add(txt8,BorderLayout.WEST);
            panelMarks.add(lblMine,BorderLayout.EAST);
            panelMarks.add(txtMine,BorderLayout.WEST);
            panelMarks.add(lblFlag,BorderLayout.EAST);
            panelMarks.add(txtFlag,BorderLayout.WEST);
            panelMarks.add(lblNew,BorderLayout.EAST);
            panelMarks.add(txtNew,BorderLayout.WEST);
            panelMarks.add(lblCrape,BorderLayout.EAST);
            panelMarks.add(txtCrape,BorderLayout.WEST);


            panelMarks.setBorder(BorderFactory.createLoweredBevelBorder());

            panelAction.setLayout(new GridLayout(1, 2));
            panelAction.add(btnOk,BorderLayout.EAST);
            panelAction.add(btnCancel,BorderLayout.WEST);
            panelAction.setBorder(BorderFactory.createLoweredBevelBorder());
            getContentPane().setLayout(new BorderLayout());
            getContentPane().repaint();
            getContentPane().add(panelMarks, BorderLayout.NORTH);
            getContentPane().add(panelAction, BorderLayout.SOUTH);
            setVisible(true);

            show();
        }
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnOk) {
                try (OutputStream output = new FileOutputStream(propFileName)) {

                     prop = new Properties();

                    // set the properties value
                    prop.setProperty("1", txt1.getText());
                    prop.setProperty("2", txt2.getText());
                    prop.setProperty("3", txt3.getText());
                    prop.setProperty("4", txt4.getText());
                    prop.setProperty("5", txt5.getText());
                    prop.setProperty("6", txt6.getText());
                    prop.setProperty("7", txt7.getText());
                    prop.setProperty("8", txt8.getText());
                    prop.setProperty("flag", txtFlag.getText());
                    prop.setProperty("new", txtNew.getText());
                    prop.setProperty("crape", txtCrape.getText());
                    prop.setProperty("mine", txtMine.getText());

                    prop.store(output, null);
                    setImageIcons();

                } catch (IOException io) {
                    io.printStackTrace();
                    Sound.play(soundsError);
                }
                dispose();

            }
            if (e.getSource() == btnCancel) {
                dispose();
            }


        }




    }
    //----------
    class SoundSettings extends JFrame implements ActionListener {
        JPanel panelSounds = new JPanel();
        JPanel panelAction = new JPanel();

        JLabel  lblWin;    JTextField txtWin;
        JLabel  lblLost;    JTextField txtLost;
        JLabel  lblError;    JTextField txtError;

        JButton btnOk;
        JButton btnCancel;

        String name;
        Properties prop = new Properties();
        String propFileName="sounds.properties";
        InputStream inputStream=null;

        SoundSettings() {
            super("Sound");
            setSize(240, 310);
            setResizable(false);
            setLocation(vPoint);

            lblWin=new JLabel("Path for Win");
            lblLost=new JLabel("Path for Lost");
            lblError=new JLabel("Path for Error");



            try {
                inputStream = new FileInputStream(propFileName);
            }
            catch (IOException e) {  Sound.play(soundsError); }

            if (inputStream !=null) {
                try {
                    prop.load(inputStream);
                    txtWin=new JTextField(prop.getProperty("win"));
                    txtLost=new JTextField(prop.getProperty("lost"));
                    txtError=new JTextField(prop.getProperty("error"));


                } catch (IOException e)  {  Sound.play(soundsError);   }


            }

            btnOk = new JButton("Ok");
            btnOk.addActionListener(this);

            btnCancel = new JButton("Cancel");
            btnCancel.addActionListener(this);


            panelSounds.setLayout(new GridLayout(6, 2));
            panelSounds.add(lblWin,BorderLayout.EAST);
            panelSounds.add(txtWin,BorderLayout.CENTER);
            panelSounds.add(lblLost,BorderLayout.EAST);
            panelSounds.add(txtLost,BorderLayout.WEST);
            panelSounds.add(lblError,BorderLayout.EAST);
            panelSounds.add(txtError,BorderLayout.WEST);


            panelAction.setBorder(BorderFactory.createLoweredBevelBorder());

            panelAction.setLayout(new GridLayout(1, 2));
            panelAction.add(btnOk,BorderLayout.EAST);
            panelAction.add(btnCancel,BorderLayout.WEST);
            panelAction.setBorder(BorderFactory.createLoweredBevelBorder());
            getContentPane().setLayout(new BorderLayout());
            getContentPane().repaint();
            getContentPane().add(panelSounds, BorderLayout.NORTH);
            getContentPane().add(panelAction, BorderLayout.SOUTH);
            setVisible(true);

            show();
        }
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == btnOk) {
                try (OutputStream output = new FileOutputStream(propFileName)) {

                    prop = new Properties();

                    // set the properties value
                    prop.setProperty("win", txtWin.getText());
                    prop.setProperty("lost", txtLost.getText());
                    prop.setProperty("error", txtError.getText());

                    prop.store(output, null);
                    setImageIcons();

                } catch (IOException io) {
                    io.printStackTrace();
                    Sound.play(soundsError);
                }
                dispose();

            }
            if (e.getSource() == btnCancel) {
                dispose();
            }


        }




    }

    //----------
    public class sortResult {
        int val;
        String ts;
        public Integer getVal() {
            return val;
        }
    }

    //---

}


